<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('booths', function (Blueprint $table) {
            $table->id();
            $table->foreignId('payment_gateway_setting_id')->constrained('payment_gateway_settings');
            $table->foreignId('user_id')->constrained('users');
            $table->string('name');
            $table->string('address');
            $table->enum('booth_status', [0, 1])->default(1)->comment('0.inactive 1.active');
            $table->string('booth_application_key');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('booths');
    }
};
