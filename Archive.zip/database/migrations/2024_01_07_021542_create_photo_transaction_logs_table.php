<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('photo_transaction_logs', function (Blueprint $table) {
            $table->id();
            $table->text('request')->nullable();
            $table->text('response');
            $table->integer('status_code');
            $table->string('status_payment');
            $table->string('photo_transaction_id')->nullable();
            $table->string('action_type')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('photo_transaction_logs');
    }
};
