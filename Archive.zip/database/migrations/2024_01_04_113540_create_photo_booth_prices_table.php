<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('photo_booth_prices', function (Blueprint $table) {
            $table->id();
            $table->text('thumbnail_image_path');
            $table->decimal('price_per_session', 10, 2);
            $table->foreignId('booth_id')->constrained('booths');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('photo_booth_prices');
    }
};
