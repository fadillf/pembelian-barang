<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PhotoBoothPriceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $photoBoothPrices = [
            [
                'booth_id' => 1,
                'thumbnail_image_path' => 'https://images.unsplash.com/photo-1594968973184-9040a5a79963?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cHJpY2V8ZW58MHx8MHx8fDA%3D',
                'price_per_session' => 6000,
            ],
            [
                'booth_id' => 2,
                'thumbnail_image_path' => 'https://images.unsplash.com/photo-1594968973184-9040a5a79963?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cHJpY2V8ZW58MHx8MHx8fDA%3D',
                'price_per_session' => 6000,
            ],
        ];
    }
}
