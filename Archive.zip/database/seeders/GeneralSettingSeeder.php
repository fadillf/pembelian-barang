<?php

namespace Database\Seeders;

use App\Models\GeneralSetting;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class GeneralSettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $generalSettings = [
            [
                'name' => 'background_app',
                'label' => 'Background Aplikasi',
                'value' => 'https://images.unsplash.com/photo-1594968973184-9040a5a79963?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cHJpY2V8ZW58MHx8MHx8fDA%3D',
                'booth_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'phone_number',
                'label' => 'Nomor Telepon Pemilik',
                'value' => 'https://images.unsplash.com/photo-1594968973184-9040a5a79963?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cHJpY2V8ZW58MHx8MHx8fDA%3D',
                'booth_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];
        GeneralSetting::insert($generalSettings);
    }
}
