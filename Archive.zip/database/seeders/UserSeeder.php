<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = [
            [
                'name' => 'Genta',
                'email' => 'muhammadgentaaththarriq@gmail.com',
                'phone' => '123456789',
                'company_name' => 'PerusahaanKU',
                'company_address' => 'Jalan Kebahagiaan',
                'user_status' => 1,
                'email_verified_at' => now(),
                'password' => bcrypt('password'), // Ganti 'password' dengan password yang diinginkan
                'remember_token' => rand(10, 10),
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'Fadillah F',
                'email' => 'fadillf.dev@gmail.com',
                'phone' => '123456789',
                'company_name' => 'PerusahaanKU',
                'company_address' => 'Jalan Kebahagiaan',
                'user_status' => 1,
                'email_verified_at' => now(),
                'password' => bcrypt('password'), // Ganti 'password' dengan password yang diinginkan
                'remember_token' => rand(10, 10),
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        User::insert($users);
    }
}
