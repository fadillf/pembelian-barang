<?php

namespace Database\Seeders;

use App\Models\PaymentGatewaySetting;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PaymentGatewaySettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $userGenta = User::where('email', 'muhammadgentaaththarriq@gmail.com')->first();
        $userFadillah = User::where('email', 'fadillf.dev@gmail.com')->first();
        $paymentGatewaySettings = [
            [
                'user_id' => $userGenta->id,
                'payment_gateway_name' => 'PEMBAYARAN_PAYMENT_GATEWAY_GENTA',
                'payment_gateway_merchant_id' => 'G601963811',
                'payment_gateway_client_key' => 'Mid-client-y4GGxrwFuiUYY_eB',
                'payment_gateway_server_key' => 'Mid-server-AZIIgH4LtaiO_nalq4fX0r9O',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'user_id' => $userFadillah->id,
                'payment_gateway_name' => 'PEMBAYARAN_PAYMENT_GATEWAY_AUL',
                'payment_gateway_merchant_id' => 'G054413263',
                'payment_gateway_client_key' => 'SB-Mid-client-aibXLX48okmIHvDT',
                'payment_gateway_server_key' => 'SB-Mid-server-_3y1PIcD8eZBhy693GuoAPRN',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];
        PaymentGatewaySetting::insert($paymentGatewaySettings);
    }
}
