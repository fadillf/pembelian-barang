<?php

namespace Database\Seeders;

use App\Models\Booth;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class BoothSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $booths = [
            [
                'user_id' => 1,
                'payment_gateway_setting_id' => 1,
                'name' => 'Booth Genta Bersahaja',
                'address' => 'Jalan Manjahlega no 1, Cileunyi, Kircon, Bandung',
                'booth_status' => 1,
                'booth_application_key' => rand(10, 10),
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'user_id' => 2,
                'payment_gateway_setting_id' => 2,
                'name' => 'Booth Aul Berceria',
                'address' => 'Jalan Sekejati no 1, Cileunyi, Kircon, Bandung',
                'booth_status' => 1,
                'booth_application_key' => rand(10, 10),
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];
        Booth::insert($booths);
    }
}
