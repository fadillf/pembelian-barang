<?php

namespace App\Enums;

enum BoothStatusEnum: int
{
    case Inactive = 0;
    case Active = 1;
}
