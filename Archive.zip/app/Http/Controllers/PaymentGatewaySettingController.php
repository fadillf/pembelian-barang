<?php

namespace App\Http\Controllers;

use App\Models\PaymentGatewaySetting;
use Illuminate\Http\Request;

class PaymentGatewaySettingController extends Controller
{
    protected $_pageTitle = 'Payment Gateway Settings';

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $loggedInUser = auth()->user();
        $data = PaymentGatewaySetting::query()
            ->where('user_id', $loggedInUser->id)
            ->get();
        return view('pages.payment-gateway-settings.index', [
            'pageTitle' => $this->_pageTitle,
            'data' => $data,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('pages.payment-gateway-settings.create', [
            'pageTitle' => $this->_pageTitle,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'payment_gateway_name' => 'required|string|max:255',
            'payment_gateway_merchant_id' => 'required',
            'payment_gateway_client_key' => 'required',
            'payment_gateway_server_key' => 'required',
        ]);
        $createdRecord = PaymentGatewaySetting::create(array_merge($validatedData, [
            'user_id' => auth()->user()->id,
        ]));
        return redirect()->route('payment-gateway-settings.index')->with('success', 'Data created successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(PaymentGatewaySetting $paymentGatewaySetting)
    {
        return view('pages.payment-gateway-settings.show', [
            'pageTitle' => $this->_pageTitle,
            'record' => $paymentGatewaySetting,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PaymentGatewaySetting $paymentGatewaySetting)
    {
        return view('pages.payment-gateway-settings.edit', [
            'pageTitle' => $this->_pageTitle,
            'record' => $paymentGatewaySetting,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, PaymentGatewaySetting $paymentGatewaySetting)
    {
        $validatedData = $request->validate([
            'payment_gateway_name' => 'required|string|max:255',
            'payment_gateway_merchant_id' => 'required',
            'payment_gateway_client_key' => 'required',
            'payment_gateway_server_key' => 'required',
        ]);
        $paymentGatewaySetting->update($validatedData);
        return redirect()->route('payment-gateway-settings.index')->with('success', 'Data updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PaymentGatewaySetting $paymentGatewaySetting)
    {
        $paymentGatewaySetting->delete();
        return redirect()->route('payment-gateway-settings.index')->with('success', 'Data deleted successfully');
    }
}
