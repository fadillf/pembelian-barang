<?php

namespace App\Http\Controllers;

use App\Enums\BoothStatusEnum;
use App\Models\Booth;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class BoothController extends Controller
{
    protected $_pageTitle = 'Booths';

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $loggedInUser = auth()->user();
        $data = Booth::query()
            ->where('user_id', $loggedInUser->id)
            ->get();
        return view('pages.booths.index', [
            'pageTitle' => $this->_pageTitle,
            'data' => $data,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('pages.booths.create', [
            'pageTitle' => $this->_pageTitle,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'payment_gateway_setting_id' => 'required|string|max:255|exists:payment_gateway_settings,id',
            'name' => 'required',
            'address' => 'required',
        ]);
        $loggedInUser = auth()->user();
        $boothApplicationKey = $loggedInUser->id . '-' . Str::random(5) . '-' . now()->timestamp;
        $createdRecord = Booth::create(array_merge($validatedData, [
            'user_id' => $loggedInUser->id,
            'booth_application_key' => $boothApplicationKey,
        ]));
        return redirect()->route('booths.index')->with('success', 'Data created successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(Booth $Booth)
    {
        return view('pages.booths.show', [
            'pageTitle' => $this->_pageTitle,
            'record' => $Booth,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Booth $Booth)
    {
        return view('pages.booths.edit', [
            'pageTitle' => $this->_pageTitle,
            'record' => $Booth,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Booth $Booth)
    {
        $validatedData = $request->validate([
            'payment_gateway_setting_id' => 'required|string|max:255|exists:payment_gateway_settings,id',
            'name' => 'required',
            'address' => 'required',
            'booth_status' => [
                'required',
                Rule::enum(BoothStatusEnum::class),
            ],
        ]);
        $Booth->update($validatedData);
        return redirect()->route('booths.index')->with('success', 'Data updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Booth $Booth)
    {
        $Booth->delete();
        return redirect()->route('booths.index')->with('success', 'Data deleted successfully');
    }
}
