<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\Midtrans\CreateSnapTokenService;
use App\Services\Midtrans\CallbackService;
use Midtrans\Notification;
use App\Models\PhotoTransaction;
use App\Models\PhotoTransactionLog;

class TransactionController extends Controller
{
    /**
     * generate qris / core api / chage payment midtrans methods for user.
     *
     * return midtrans payback
     */
    public function generateChargePayment(Request $request)
    {
        $validatedData = $request->validate([
            // 'order_id'                  => 'required',
            'amount'                    => 'required',
            'booth_id'                  => 'required',
            'payment_type'              => 'required',
        ]);

        $order_id = uniqid().now()->format('YmdHis');
        $validatedData['order_id'] = $order_id;
        
        $result = PhotoTransaction::create($validatedData);

        if($result){
            $order = [
                'order_id' => $order_id,
                'gross_amount' => $validatedData['amount'],
                'item_details' => [
                    [
                        'id'        => 1,
                        'price'     => (int) $validatedData['amount'],
                        'quantity'  => 1,
                        'name'      => 'Photo 1',
                    ]
                ],
                'customer_details' => [
                    'first_name'=> 'Booth 1',
                    'email'     => 'fadillf.dev@gmail.com',
                    'phone'     => '',
                ]
            ];
            $snap = new CreateSnapTokenService($order, $validatedData['booth_id']);
            $pay_respon = $snap->getSnapToken();

            $photoTransactionLog = new PhotoTransactionLog;
            $photoTransactionLog->request = json_encode($order);
            $photoTransactionLog->response = json_encode($pay_respon);
            $photoTransactionLog->status_code = $pay_respon->status_code;
            $photoTransactionLog->status_payment = $pay_respon->transaction_status;
            $photoTransactionLog->photo_transaction_id = $pay_respon->order_id;
            $photoTransactionLog->action_type = 'transaction_charge';
            $photoTransactionLog->save();
        }
        
        $respon = [
            'status'    => 'success',
            'message'   => 'Data created successfully',
            'data'      => $result
        ];

        return response()->json($respon);
    }

    /**
     * generate snap token for payment using snap.
     *
     * return midtrans payback
     */
    public function generateSnapPayment()
    {

    }

    /**
     * Check transaction status to midtrans.
     *
     * return midtrans payback
     */
    public function checkStatus(Request $request)
    {
        $photoTransaction = PhotoTransaction::where('order_id', $request->order_id)->first();
        if($photoTransaction){
            $respon = [
                'status'    => 'success',
                'message'   => 'Data ditemukan',
                'data'      => $photoTransaction
            ];
    
            return response()->json($respon);
        }
    }

    /**
     * Getting webhook from midtrans after user do something to the paymentss.
     *
     * return midtrans payback
     */
    public function receiveWebhook(Request $request)
    {
        $callback = new CallbackService($request);

        // if ($callback->isSignatureKeyVerified()) {
            $notification = $callback->getNotification();
            $order = $callback->getOrder();

            if ($callback->isSuccess()) {
                PhotoTransaction::where('order_id', $order->order_id)->update([
                    'photo_transaction_status' => 2,
                ]);
            }

            if ($callback->isExpire()) {
                PhotoTransaction::where('order_id', $order->order_id)->update([
                    'photo_transaction_status' => 3,
                ]);
            }

            if ($callback->isCancelled()) {
                PhotoTransaction::where('order_id', $order->order_id)->update([
                    'photo_transaction_status' => 4,
                ]);
            }

            $photoTransactionLog = new PhotoTransactionLog;
            $photoTransactionLog->response = json_encode($notification);
            $photoTransactionLog->status_code = $notification->status_code;
            $photoTransactionLog->status_payment = $notification->transaction_status;
            $photoTransactionLog->photo_transaction_id = $notification->order_id;
            $photoTransactionLog->action_type = 'transaction_callback';
            $photoTransactionLog->save();

            return response()
                ->json([
                    'success' => true,
                    'message' => 'Notifikasi berhasil diproses',
                ]);
        // } else {
        //     return response()
        //         ->json([
        //             'error' => true,
        //             'message' => 'Signature key tidak terverifikasi',
        //         ], 403);
        // }
    }
}
