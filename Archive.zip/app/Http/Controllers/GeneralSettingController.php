<?php

namespace App\Http\Controllers;

use App\Models\GeneralSetting;
use Illuminate\Http\Request;

class GeneralSettingController extends Controller
{
    protected $_pageTitle = 'General Settings';

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $loggedInUser = auth()->user();
        $data = GeneralSetting::query()
            ->whereHas('booth', function ($query) use ($loggedInUser) {
                $query->where('user_id', $loggedInUser->id);
            })->get();
        return view('pages.general-settings.index', [
            'pageTitle' => $this->_pageTitle,
            'data' => $data,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('pages.general-settings.create', [
            'pageTitle' => $this->_pageTitle,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'booth_id' => [
                'required',
                'integer',
                'exists:payment_gateway_settings,id',
            ],
            'name' => 'required|max:255',
            'label' => 'required|max:255',
            'value' => 'required|max:255',
        ]);
        $createdRecord = GeneralSetting::create(array_merge($validatedData));
        return redirect()->route('general-settings.index')->with('success', 'Data created successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(GeneralSetting $GeneralSetting)
    {
        return view('pages.general-settings.show', [
            'pageTitle' => $this->_pageTitle,
            'record' => $GeneralSetting,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(GeneralSetting $GeneralSetting)
    {
        return view('pages.general-settings.edit', [
            'pageTitle' => $this->_pageTitle,
            'record' => $GeneralSetting,
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, GeneralSetting $GeneralSetting)
    {
        $validatedData = $request->validate([
            'booth_id' => [
                'required',
                'integer',
                'exists:payment_gateway_settings,id',
            ],
            'name' => 'required|max:255',
            'label' => 'required|max:255',
            'value' => 'required|max:255',
        ]);
        $GeneralSetting->update($validatedData);
        return redirect()->route('general-settings.index')->with('success', 'Data updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(GeneralSetting $GeneralSetting)
    {
        $GeneralSetting->delete();
        return redirect()->route('general-settings.index')->with('success', 'Data deleted successfully');
    }
}
