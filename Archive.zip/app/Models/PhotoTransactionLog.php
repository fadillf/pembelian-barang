<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PhotoTransactionLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'request',
        'response',
        'status_code',
        'status_payment',
        'photo_transaction_id',
        'action_type'
    ];
}
