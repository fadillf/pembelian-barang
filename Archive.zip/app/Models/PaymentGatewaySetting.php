<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PaymentGatewaySetting extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id',
        'payment_gateway_name',
        'payment_gateway_merchant_id',
        'payment_gateway_client_key',
        'payment_gateway_server_key',
    ];

    public function user() {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function booth() {
        return $this->hasMany(Booth::class, 'payment_gateway_setting_id', 'id');
    }
}
