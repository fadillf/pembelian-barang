<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Booth extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id',
        'payment_gateway_setting_id',
        'name',
        'address',
        'booth_status',
        'booth_application_key',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function paymentGatewaySetting()
    {
        return $this->belongsTo(PaymentGatewaySetting::class, 'payment_gateway_setting_id', 'id');
    }
}
