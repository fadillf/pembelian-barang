<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class GeneralSetting extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'booth_id',
        'name',
        'label',
        'value',
    ];

    public function booth()
    {
        return $this->belongsTo(Booth::class, 'booth_id', 'id');
    }
}
