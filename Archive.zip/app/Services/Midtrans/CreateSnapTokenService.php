<?php

namespace App\Services\Midtrans;

use Midtrans\Snap;
use Midtrans\CoreApi;
use App\Services\Midtrans\Midtrans;
use App\Models\PaymentGatewaySetting;
use Midtrans\Config;

class CreateSnapTokenService extends Midtrans
{
    protected $order;

    public function __construct($order, $booth_id)
    {
        $this->order = (object)$order;
        $this->setCredentialPaymentGateway($booth_id);
    }

    public function getSnapToken()
    {
        $params = [
            "payment_type" =>"gopay",
            'transaction_details' => [
                'order_id' => $this->order->order_id,
                'gross_amount' => (int) $this->order->gross_amount,
            ],
            'item_details' => $this->order->item_details,
            'customer_details' => $this->order->customer_details,
            // "qris" => [
            //     "acquirer" => "gopay"
            // ],
            "gopay" => [
                "enable_callback" => true,
                "callback_url" => "fadillf.my.id"
            ],
            "custom_expiry" => [
                "expiry_duration" => 1,
                "unit" => "minute"
            ],
        ];

        $snapToken = CoreApi::charge($params);

        return $snapToken;
    }

    protected function setCredentialPaymentGateway($booth_id){
        // $PaymentGatewaySetting = PaymentGatewaySetting::where('id', '2')->first();
        $PaymentGatewaySetting = PaymentGatewaySetting::whereHas('booth', function($q) use($booth_id){
            $q->where('id', $booth_id);
        })->first();

        if($PaymentGatewaySetting){
            // dd($PaymentGatewaySetting->payment_gateway_server_key);
            // $midtrans = new Midtrans($PaymentGatewaySetting->payment_gateway_server_key);

            Config::$serverKey      = $PaymentGatewaySetting->payment_gateway_server_key;
            Config::$isProduction   = false;
            Config::$isSanitized    = false;
            Config::$is3ds          = false;
        }
    }
}