<?php
namespace App\Services\Midtrans;

use App\Models\PhotoTransaction;
use App\Models\PaymentGatewaySetting;
use App\Services\Midtrans\Midtrans;
use Midtrans\Notification;

class CallbackService extends Midtrans
{
    protected $notification;
    protected $order;
    protected $serverKey;

    public function __construct($notification)
    {
        $this->notification = $notification;
        // $this->serverKey = 'SB-Mid-server-_3y1PIcD8eZBhy693GuoAPRN';
        $this->_handleNotification();
        $this->_setPaymentGateway($this->order->booth_id);
    }

    public function isSignatureKeyVerified()
    {
        return ($this->_createLocalSignatureKey() == $this->notification->signature_key);
    }

    public function isSuccess()
    {
        $statusCode         = $this->notification->status_code;
        $transactionStatus  = $this->notification->transaction_status;
        $fraudStatus        = !empty($this->notification->fraud_status) ? ($this->notification->fraud_status == 'accept') : true;

        return ($statusCode == 200 && $fraudStatus && ($transactionStatus == 'capture' || $transactionStatus == 'settlement'));
    }

    public function isExpire()
    {
        return ($this->notification->transaction_status == 'expire');
    }

    public function isCancelled()
    {
        return ($this->notification->transaction_status == 'cancel');
    }

    public function getNotification()
    {
        return $this->notification;
    }

    public function getOrder()
    {
        return $this->order;
    }

    protected function _createLocalSignatureKey()
    {
        $orderId    = $this->order->order_id;
        $statusCode = $this->notification->status_code;
        $grossAmount= $this->order->amount;
        $serverKey  = $this->serverKey;
        $input      = $orderId . $statusCode . $grossAmount . $serverKey;
        $signature  = openssl_digest($input, 'sha512');

        return $signature;
    }

    protected function _handleNotification()
    {
        // $notification = new Notification();
        // dd($notification);

        $order_id = $this->notification->order_id;
        $order = PhotoTransaction::where('order_id', $order_id)->first();

        // $this->notification = $this->notification;
        $this->order = $order;
    }

    protected function _setPaymentGateway($booth_id=""){
        $PaymentGatewaySetting = PaymentGatewaySetting::whereHas('booth', function($q) use($booth_id){
            $q->where('id', $booth_id);
        })->first();
        $this->serverKey = $PaymentGatewaySetting->payment_gateway_server_key;
    }
}