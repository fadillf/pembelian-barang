<div class="mt-6 space-y-2">
    <x-form.label
        for="payment_gateway_name"
        value="Payment Gateway Name"
    />
    <x-form.input
        id="payment_gateway_name"
        name="payment_gateway_name"
        type="text"
        class="block w-full"
        :value="old('payment_gateway_name', $record->payment_gateway_name ?? '')"
        placeholder="Payment Gateway Name"
    />

    <x-form.error :messages="$errors->get('payment_gateway_name')" />
</div>

<div class="mt-6 space-y-2">
    <x-form.label
        for="payment_gateway_merchant_id"
        value="Payment Gateway Merchant ID"
    />

    <x-form.input
        id="payment_gateway_merchant_id"
        name="payment_gateway_merchant_id"
        type="text"
        class="block w-full"
        :value="old('payment_gateway_merchant_id', $record->payment_gateway_merchant_id ?? '')"
        placeholder="Payment Gateway Merchant ID"
    />

    <x-form.error :messages="$errors->get('payment_gateway_merchant_id')" />
</div>

<div class="mt-6 space-y-2">
    <x-form.label
        for="payment_gateway_client_key"
        value="Payment Gateway Client Key"
    />

    <x-form.input
        id="payment_gateway_client_key"
        name="payment_gateway_client_key"
        type="text"
        class="block w-full"
        :value="old('payment_gateway_client_key', $record->payment_gateway_client_key ?? '')"
        placeholder="Payment Gateway Client Key"
    />

    <x-form.error :messages="$errors->get('payment_gateway_client_key')" />
</div>

<div class="mt-6 space-y-2">
    <x-form.label
        for="payment_gateway_server_key"
        value="Payment Gateway Server Key"
    />

    <x-form.input
        id="payment_gateway_server_key"
        name="payment_gateway_server_key"
        type="text"
        class="block w-full"
        :value="old('payment_gateway_server_key', $record->payment_gateway_server_key ?? '')"
        placeholder="Payment Gateway Server Key"
    />

    <x-form.error :messages="$errors->get('payment_gateway_server_key')" />
</div>

<div class="flex items-center gap-4">
    <x-button>
        {{ __('Save') }}
    </x-button>

    @if (session('status') === 'password-updated')
        <p
            x-data="{ show: true }"
            x-show="show"
            x-transition
            x-init="setTimeout(() => show = false, 2000)"
            class="text-sm text-gray-600 dark:text-gray-400"
        >
            {{ __('Saved.') }}
        </p>
    @endif
</div>
