<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between">
            <h2 class="font-semibold text-xl leading-tight">
                {{ __($pageTitle) }}
            </h2>

            <a href="{{ route('booths.create') }}"
                class="px-4 py-2 bg-green-600 rounded text-white">Create</a>
        </div>
    </x-slot>

    @if (session('success'))
        <div class="bg-green-500 text-white p-4 mb-4 rounded">
            {{ session('success') }}
        </div>
    @endif

    <div class="overflow-x-auto">
        <table class="min-w-full bg-white border border-gray-300 rounded">
            <thead>
                <tr class="bg-gray-100">
                    <th class="py-2 px-4 border-b border-r"">Owner</th>
                    <th class="py-2 px-4 border-b border-r"">Payment Gateway</th>
                    <th class="py-2 px-4 border-b border-r"">Booth Name</th>
                    <th class="py-2 px-4 border-b border-r"">Booth Address</th>
                    <th class="py-2 px-4 border-b border-r"">Booth Status</th>
                    <th class="py-2 px-4 border-b border-r"">Booth Application Key</th>
                    <th class="py-2 px-4 border-b border-r"">Created At</th>
                    <th class="py-2 px-4 border-b border-r"">Updated At</th>
                    <th class="py-2 px-4 border-b border-r"">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($data as $item)
                    <tr class="hover:bg-gray-200 transition-all">
                        <td class="py-2 px-4 border-b border-r"">{{ $item->user->name }}</td>
                        <td class="py-2 px-4 border-b border-r"">{{ $item->paymentGatewaySetting->payment_gateway_name }}</td>
                        <td class="py-2 px-4 border-b border-r"">{{ $item->name }}</td>
                        <td class="py-2 px-4 border-b border-r"">{{ $item->address }}</td>
                        <td class="py-2 px-4 border-b border-r"">{{ $item->booth_status }}</td>
                        <td class="py-2 px-4 border-b border-r"">{{ $item->booth_application_key }}</td>
                        <td class="py-2 px-4 border-b border-r"">{{ $item->created_at }}</td>
                        <td class="py-2 px-4 border-b border-r"">{{ $item->updated_at }}</td>
                        <td class="py-2 px-4 border-b border-r">
                            <div class="flex space-x-2">
                                <a href="{{ route('booths.edit', ['booth' => $item->id]) }}"
                                    class="text-sm py-1 px-2 mr-2 bg-blue-500 text-white rounded hover:bg-blue-600">Edit</a>
                                <form
                                    action="{{ route('booths.destroy', ['booth' => $item->id]) }}"
                                    method="POST" style="display: inline-block">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit"
                                        class="text-sm py-1 px-2 bg-red-500 text-white rounded hover:bg-red-600"
                                        onclick="return confirm('Are you sure you want to delete this item?')">Delete</button>
                                </form>

                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</x-app-layout>
