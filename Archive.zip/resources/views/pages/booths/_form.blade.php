<div class="mt-6 space-y-2">
    <x-form.label
        for="payment_gateway_setting_id"
        value="Payment Gateway Setting"
    />
    <x-form.input
        id="payment_gateway_setting_id"
        name="payment_gateway_setting_id"
        type="text"
        class="block w-full"
        :value="old('payment_gateway_setting_id', $record->payment_gateway_setting_id ?? '')"
        placeholder="Payment Gateway Setting"
    />

    <x-form.error :messages="$errors->get('payment_gateway_setting_id')" />
</div>

<div class="mt-6 space-y-2">
    <x-form.label
        for="name"
        value="Booth Name"
    />

    <x-form.input
        id="name"
        name="name"
        type="text"
        class="block w-full"
        :value="old('name', $record->name ?? '')"
        placeholder="Booth Name"
    />

    <x-form.error :messages="$errors->get('name')" />
</div>

<div class="mt-6 space-y-2">
    <x-form.label
        for="address"
        value="Booth Address"
    />

    <x-form.input
        id="address"
        name="address"
        type="text"
        class="block w-full"
        :value="old('address', $record->address ?? '')"
        placeholder="Booth Address"
    />

    <x-form.error :messages="$errors->get('address')" />
</div>

@if($isEditing)
<div class="mt-6 space-y-2">
    <x-form.label
        for="booth_status"
        value="Status"
    />

    <x-form.input
        id="booth_status"
        name="booth_status"
        type="text"
        class="block w-full"
        :value="old('booth_status', $record->booth_status ?? '')"
        placeholder="Status"
    />

    <x-form.error :messages="$errors->get('booth_status')" />
</div>
@endif

<div class="flex items-center gap-4">
    <x-button>
        {{ __('Save') }}
    </x-button>
</div>
