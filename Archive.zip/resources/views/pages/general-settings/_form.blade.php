<div class="mt-6 space-y-2">
    <x-form.label
        for="booth_id"
        value="Booth ID"
    />
    <x-form.input
        id="booth_id"
        name="booth_id"
        type="text"
        class="block w-full"
        :value="old('booth_id', $record->booth_id ?? '')"
        placeholder="Booth ID"
    />

    <x-form.error :messages="$errors->get('booth_id')" />
</div>

<div class="mt-6 space-y-2">
    <x-form.label
        for="name"
        value="Name"
    />

    <x-form.input
        id="name"
        name="name"
        type="text"
        class="block w-full"
        :value="old('name', $record->name ?? '')"
        placeholder="Name"
    />

    <x-form.error :messages="$errors->get('name')" />
</div>

<div class="mt-6 space-y-2">
    <x-form.label
        for="label"
        value="Label"
    />

    <x-form.input
        id="label"
        name="label"
        type="text"
        class="block w-full"
        :value="old('label', $record->label ?? '')"
        placeholder="Label"
    />

    <x-form.error :messages="$errors->get('label')" />
</div>

<div class="mt-6 space-y-2">
    <x-form.label
        for="value"
        value="Value"
    />

    <x-form.input
        id="value"
        name="value"
        type="text"
        class="block w-full"
        :value="old('value', $record->value ?? '')"
        placeholder="Value"
    />

    <x-form.error :messages="$errors->get('value')" />
</div>

<div class="flex items-center gap-4">
    <x-button>
        {{ __('Save') }}
    </x-button>
</div>
